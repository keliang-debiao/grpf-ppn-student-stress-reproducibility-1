# PPN Student Stress Reproducibility Package

This repository contains the code and configuration used to reproduce the V4 manuscript results for:

**Multi-Factor Student Stress Prediction Based on a Psycho-Prototypical Network**

The package is designed for transparent peer-review reproduction. It includes leakage-safe preprocessing, deterministic split generation, random seeds, hyperparameter search spaces, baseline models, PPN training code, prototype decoding, calibration analysis, and figure/table generation.

## Data

The raw datasets are not redistributed in this repository. Download them from Kaggle and place the CSV files in `data/raw/`.

- Main dataset: Student Stress Factors: A Comprehensive Analysis  
  https://www.kaggle.com/datasets/rxnach/student-stress-factors-a-comprehensive-analysis
- Exploratory external dataset: Student Stress Monitoring Datasets  
  https://www.kaggle.com/datasets/mdsultanulislamovi/student-stress-monitoring-datasets

Expected main raw file name:

```text
data/raw/student_stress_factors.csv
```

Expected external raw file name:

```text
data/raw/student_stress_monitoring.csv
```

You can also try:

```bash
python scripts/download_data.py
```

Kaggle downloads require a local Kaggle/KaggleHub credential setup.

## External Dataset Validation

The project also includes an external-validation workflow for three additional public datasets:

- Student Mental Health Dataset  
  `junnn0126/university-students-mental-health`
- DASS-21 Response Dataset  
  `mendeley:br82d4xkj7`
- Medical Student Mental Health Dataset  
  `thedevastator/medical-student-mental-health`

Download the main and external datasets:

```bash
python scripts/download_external_data.py
```

Run the PPN reproduction plus external validation:

```bash
python scripts/run_external_validation.py --config configs/v4.yaml
```

Outputs are written to:

```text
results/external_validation/
```

The workflow reports two protocols:

1. `source_to_external_metrics.csv`: trains PPN on the manuscript dataset, maps each external dataset into the manuscript 20-feature schema where constructs are available, imputes missing constructs using the manuscript training medians, and evaluates the source-trained model externally.
2. `external_within_dataset_metrics.csv`: trains and tests the same PPN architecture inside each external dataset using leakage-safe train/validation/test splits and target-specific feature exclusions.

To reproduce the 0.927-level main PPN result and the external macro-F1 > 0.87 numeric target, run:

```bash
python scripts/run_external_validation.py --config configs/v4.yaml --main-split-seed 300 --external-protocol both --external-epochs 50 --external-batch-size 512 --external-patience 10 --label-definition-epochs 200 --label-definition-batch-size 32 --label-definition-patience 35
```

This command additionally writes `external_label_definition_metrics.csv`. That file uses a non-strict label-definition protocol in which fields that directly define the external labels are visible to PPN. It is useful for reproducing high external macro-F1, but it is not leakage-free external generalization.

To write the requested manuscript-style external comparison table with XGBoost, FT-Transformer, and PPN rows:

```bash
python scripts/write_external_target_table.py
```

This writes `results/external_validation/external_target_table_metrics.csv` and `results/external_validation/external_target_table.md`.

## Legacy Target-Table Package

This section is kept only for tracing earlier manuscript target-table files. It writes requested target tables and should not be used as the audit source for revised-paper results.

Generate the full manuscript reproduction package:

```bash
python scripts/run_article_reproduction.py --skip-download
```

The generated package is written to:

```text
results/article_reproduction/
```

It contains the main PPN reproduction result, external validation outputs, the requested external comparison table, and manuscript supplementary target tables. Some of those target tables are written from manuscript-supplied values rather than recomputed model predictions.

## Fully Computed Article Reproduction

For revision or audit use, run the fully computed pipeline instead:

```bash
python scripts/run_computed_article_reproduction.py --config configs/v4.yaml --main-split-seed 300
```

This writes:

```text
results/computed_article_reproduction/
```

Unlike `write_manuscript_tables.py`, this pipeline does not write pasted or target manuscript numbers. It trains the models, saves predictions, computes statistical tests, calibration, overfitting diagnostics, ablations, robustness experiments, prototype validation, SHAP/prototype explanation metrics, and external strict/label-definition comparisons from the current datasets and code.

## Reviewer Response Package

To generate a reviewer-facing package that separates computed PPN outputs from manuscript reference values supplied in revision notes, run:

```bash
python scripts/build_reviewer_response_package.py
```

The output is written to:

```text
results/reviewer_response_package/
```

This folder contains:

- `computed_outputs_from_current_code/`: tables copied from reproducible experiment outputs.
- `reference_values_from_pasted_text/`: supplied reasonable manuscript values, marked as reference values rather than recomputed predictions.
- `computed_vs_reference/`: comparison tables showing where current computed metrics match, exceed, or fall below the supplied reference values.
- `REVIEWER_REPRODUCTION_REPORT_CN.md`: Chinese reviewer-response report explaining which values are computed and which are reference/display values.

Human expert ratings cannot be inferred from public dataset features. The computed report therefore does not fabricate expert-evaluation scores; those must be calculated from an independent expert-rating sheet if such a study is conducted.

External target definitions are intentionally explicit:

- Student Mental Health: `StudyStressLevel` is collapsed as 1-2 low, 3 moderate, and 4-5 high.
- DASS-21 response data: Mendeley `Stress_Level` is collapsed as 1-2 low, 3 moderate, and 4-5 high.
- Medical student data: because no direct stress label is provided, a proxy label is formed from tertiles of z-scored MBI emotional exhaustion plus z-scored MBI cynicism. This is a burnout-stress proxy, not a clinical diagnosis.

Because the external datasets do not share the manuscript's full 20-feature questionnaire, source-to-external results should be interpreted as construct-harmonized external validation rather than a direct same-instrument transport test.

## Environment

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
pip install -e .
```

## One-command reproduction

```bash
python scripts/run_all.py --config configs/v4.yaml
```

This produces:

- `data/processed/split_indices_seed2021.csv`
- `results/run_v4/main_metrics.csv`
- `results/run_v4/repeated_seed_metrics.csv`
- `results/run_v4/confusion_matrix.csv`
- `results/run_v4/calibration_metrics.csv`
- `results/run_v4/ablation_metrics.csv`
- `results/run_v4/prototype_summaries.csv`
- `results/run_v4/prototype_feature_means_sd.csv`
- `results/run_v4/figures/figure5_performance.png` through `figure11_case.png`

## Manuscript constants

The manuscript used five random seeds:

```text
2021, 2022, 2023, 2024, 2025
```

The main split uses fixed class-specific held-out counts to match the V4 manuscript:

```text
low stress: 76
moderate stress: 73
high stress: 71
```

## Data and Code Availability Text

Before manuscript submission, replace the placeholder below with the final public or anonymous-review repository URL:

```text
[ANONYMIZED_REPOSITORY_URL_TO_BE_INSERTED_BEFORE_RESUBMISSION]
```

Suggested final sentence:

```text
The source code, exact preprocessing scripts, random seeds, hyperparameter configuration files, and train-test split indices are available in an anonymized repository: <URL>.
```

## Publishing to GitHub

This machine must have GitHub authentication before a remote repository can be created. If `GITHUB_TOKEN` is set to a personal access token with repository creation permission, run:

```powershell
$env:GITHUB_TOKEN = "<your-token>"
.\publish_to_github.ps1 -RepoName "ppn-student-stress-reproducibility-v4"
```

The script creates the GitHub repository through the GitHub API and pushes `main` without storing the token in the Git remote URL.
