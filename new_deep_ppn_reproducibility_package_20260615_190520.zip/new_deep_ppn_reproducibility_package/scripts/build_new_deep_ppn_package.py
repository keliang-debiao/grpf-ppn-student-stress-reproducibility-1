from __future__ import annotations

import shutil
import zipfile
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PACKAGE_DIR = ROOT / "results" / "new_deep_ppn_reproducibility_package"


def copy_file(source: Path, target: Path) -> None:
    if not source.exists():
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def copy_tree(source: Path, target: Path) -> None:
    if not source.exists():
        return
    if target.exists():
        shutil.rmtree(target)
    shutil.copytree(
        source,
        target,
        ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".pytest_cache", "package"),
    )


def write_readme() -> None:
    text = """# New Deep PPN Reproducibility Package

This package reproduces the redesigned end-to-end PPN model:

- `DeepPsychoPrototypicalNetwork`: feature gate + residual tabular encoder + learnable prototypes.
- Prototype-aware prediction: neural logits, class soft-min prototype logits, and learnable prototype-distance logits.
- `DeepPsychoPrototypicalEnsemble`: two PPN members with probability averaging for repeated-split stability.
- Prototype explanation outputs: nearest-neighbor purity, top contributing features, and standardized prototype profiles.

## Locked Results

Main Student Stress dataset, 10 repeated random splits:

- Accuracy: 0.9282 +/- 0.0083
- Macro-F1: 0.9284 +/- 0.0085
- Balanced Accuracy: 0.9283 +/- 0.0083
- AUC: 0.9676 +/- 0.0101

External label-definition within-dataset validation:

- Student Mental Health Dataset Macro-F1: 0.9644
- DASS-21 Response Dataset Macro-F1: 0.9369
- Medical Student Mental Health Dataset Macro-F1: 0.8911

## Reproduction Commands

Run the main 10-seed experiment:

```powershell
uv run python scripts/run_deep_ppn_experiments.py --config configs/v4.yaml --raw-dir data/raw --output-dir results/deep_ppn_iter5_ensemble2_main --main-split-seed 300 --deep-ppn-config results/deep_ppn_iter5_ensemble2_main/locked_deep_ppn_config.yaml --final-epochs 250 --seeds 2021 2022 2023 2024 2025 2026 2027 2028 2029 2030 --skip-external
```

Run the external label-definition validation using the locked model configuration:

```powershell
uv run python scripts/run_deep_ppn_experiments.py --config configs/v4.yaml --raw-dir data/raw --output-dir results/deep_ppn_iter5_ensemble2_external_label --deep-ppn-config results/deep_ppn_iter5_ensemble2_main/locked_deep_ppn_config.yaml --reuse-main-results results/deep_ppn_iter5_ensemble2_main --external-seeds 2021 2022 2023 2024 2025 --external-protocols label_definition --external-epochs 120 --external-pretrain-epochs 10 --external-patience 20 --external-batch-size 128
```

## Key Files

- `src/ppn/models/deep_ppn.py`: redesigned model and ensemble.
- `scripts/run_deep_ppn_experiments.py`: training, evaluation, external validation, and reporting.
- `results/deep_ppn_iter5_ensemble2_main/locked_deep_ppn_config.yaml`: locked final model config.
- `results/deep_ppn_iter5_ensemble2_main/deep_ppn_main_summary.csv`: main result summary.
- `results/deep_ppn_iter5_ensemble2_external_label/deep_ppn_external_summary.csv`: external result summary.
- `results/deep_ppn_iter5_ensemble2_main/deep_ppn_prototype_explanations.csv`: prototype explanations.

Note: label-definition external validation is not strict leakage-free transfer. It is included as a label-consistent external reproducibility protocol.
"""
    (PACKAGE_DIR / "README_REPRODUCTION.md").write_text(text, encoding="utf-8")


def main() -> None:
    if PACKAGE_DIR.exists():
        shutil.rmtree(PACKAGE_DIR)
    PACKAGE_DIR.mkdir(parents=True)

    for name in ["pyproject.toml", "requirements.txt", "uv.lock", "README.md", ".gitignore"]:
        copy_file(ROOT / name, PACKAGE_DIR / name)

    copy_tree(ROOT / "src", PACKAGE_DIR / "src")
    copy_tree(ROOT / "configs", PACKAGE_DIR / "configs")
    copy_tree(ROOT / "data" / "raw", PACKAGE_DIR / "data" / "raw")

    for script in ["run_deep_ppn_experiments.py", "build_new_deep_ppn_package.py"]:
        copy_file(ROOT / "scripts" / script, PACKAGE_DIR / "scripts" / script)

    for result_dir in ["deep_ppn_iter5_ensemble2_main", "deep_ppn_iter5_ensemble2_external_label"]:
        copy_tree(ROOT / "results" / result_dir, PACKAGE_DIR / "results" / result_dir)

    write_readme()

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_path = ROOT.parent / f"new_deep_ppn_reproducibility_package_{timestamp}.zip"
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in PACKAGE_DIR.rglob("*"):
            if path.is_file():
                archive.write(path, path.relative_to(PACKAGE_DIR.parent))
    print(zip_path)


if __name__ == "__main__":
    main()
