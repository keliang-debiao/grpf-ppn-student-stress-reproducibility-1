from __future__ import annotations

import argparse
import json
import math
import random
import shutil
from dataclasses import asdict, dataclass, fields
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import yaml
from sklearn.cluster import KMeans
from sklearn.metrics import accuracy_score, f1_score, recall_score

from ppn.config import ensure_dir, load_config
from ppn.data import PreparedSplit, load_main_dataset, prepare_split
from ppn.evaluate import metric_row, save_confusion
from ppn.external import EXTERNAL_DATASETS, load_external_dataset, prepare_external_split
from ppn.models.deep_ppn import (
    DeepPsychoPrototypicalEnsemble,
    DeepPsychoPrototypicalNetwork,
    prototype_compactness_loss,
    prototype_diversity_loss,
    prototype_negative_separation_loss,
    prototype_separation_margin_loss,
    set_seed,
)


@dataclass
class DeepPPNConfig:
    d_model: int = 96
    hidden_dim: int = 128
    residual_blocks: int = 3
    mlp_layers: int = 1
    num_prototypes: int = 9
    dropout: float = 0.12
    prototype_temperature: float = 1.0
    classifier_weight: float = 0.65
    prototype_weight: float = 0.35
    distance_head_weight: float = 0.0
    normalize_embeddings: bool = False
    feature_gate_enabled: bool = True
    learning_rate: float = 0.001
    weight_decay: float = 0.001
    optimizer: str = "AdamW"
    scheduler: str = "cosine"
    deterministic_loader: bool = True
    batch_size: int = 64
    epochs: int = 220
    pretrain_epochs: int = 20
    patience: int = 35
    label_smoothing: float = 0.05
    alpha: float = 0.03
    beta: float = 0.08
    diversity_weight: float = 0.02
    proto_ce_weight: float = 0.2
    separation_margin: float = 0.5
    separation_loss: str = "margin"
    class_balanced_loss: bool = True
    gradient_clip: float | None = 5.0
    kmeans_init: bool = True
    encoder_variant: str = "residual"
    ensemble_size: int = 1


@dataclass
class TrainedDeepPPN:
    model: DeepPsychoPrototypicalNetwork
    history: pd.DataFrame
    best_epoch: int
    best_val_macro_f1: float


def class_weights(y: np.ndarray, device: torch.device) -> torch.Tensor | None:
    counts = np.bincount(y.astype(int), minlength=3).astype(float)
    weights = counts.sum() / (len(counts) * np.maximum(counts, 1.0))
    return torch.tensor(weights, dtype=torch.float32, device=device)


def initialize_prototypes(model: DeepPsychoPrototypicalNetwork, x_train: np.ndarray, y_train: np.ndarray, seed: int) -> None:
    device = next(model.parameters()).device
    model.eval()
    with torch.no_grad():
        z = model.encode(torch.tensor(x_train, dtype=torch.float32, device=device)).detach().cpu().numpy()
    proto = model.prototypes.detach().cpu().numpy()
    proto_classes = model.prototype_classes.detach().cpu().numpy()
    rng = np.random.default_rng(seed)
    for cls in sorted(np.unique(proto_classes)):
        slots = np.where(proto_classes == cls)[0]
        cls_z = z[y_train == cls]
        if len(cls_z) == 0:
            continue
        if len(cls_z) >= len(slots):
            centers = KMeans(n_clusters=len(slots), random_state=seed, n_init=10).fit(cls_z).cluster_centers_
        else:
            centers = cls_z[rng.choice(np.arange(len(cls_z)), size=len(slots), replace=True)]
        proto[slots] = centers
    with torch.no_grad():
        model.prototypes.copy_(torch.tensor(proto, dtype=torch.float32, device=device))


def train_deep_ppn(
    x_train: np.ndarray,
    y_train: np.ndarray,
    x_val: np.ndarray,
    y_val: np.ndarray,
    cfg: DeepPPNConfig,
    seed: int,
) -> TrainedDeepPPN:
    set_seed(seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if cfg.ensemble_size > 1:
        member_cfg = DeepPPNConfig(**asdict(cfg))
        member_cfg.ensemble_size = 1
        models = []
        histories = []
        best_epochs = []
        best_scores = []
        for member in range(cfg.ensemble_size):
            trained = train_deep_ppn(x_train, y_train, x_val, y_val, member_cfg, seed + member * 7919)
            models.append(trained.model)
            history = trained.history.copy()
            history["ensemble_member"] = member
            histories.append(history)
            best_epochs.append(trained.best_epoch)
            best_scores.append(trained.best_val_macro_f1)
        ensemble = DeepPsychoPrototypicalEnsemble(models).to(device)
        pred, _prob, _dist = predict_deep_ppn(ensemble, x_val)
        return TrainedDeepPPN(
            model=ensemble,
            history=pd.concat(histories, ignore_index=True),
            best_epoch=int(round(float(np.mean(best_epochs)))),
            best_val_macro_f1=float(f1_score(y_val, pred, average="macro", zero_division=0)),
        )
    model = DeepPsychoPrototypicalNetwork(
        input_dim=x_train.shape[1],
        d_model=cfg.d_model,
        hidden_dim=cfg.hidden_dim,
        residual_blocks=cfg.residual_blocks,
        mlp_layers=cfg.mlp_layers,
        num_prototypes=cfg.num_prototypes,
        dropout=cfg.dropout,
        prototype_temperature=cfg.prototype_temperature,
        classifier_weight=cfg.classifier_weight,
        prototype_weight=cfg.prototype_weight,
        distance_head_weight=cfg.distance_head_weight,
        normalize_embeddings=cfg.normalize_embeddings,
        feature_gate_enabled=cfg.feature_gate_enabled,
        encoder_variant=cfg.encoder_variant,
    ).to(device)
    optimizer_cls = torch.optim.Adam if str(cfg.optimizer).lower() == "adam" else torch.optim.AdamW
    opt = optimizer_cls(model.parameters(), lr=cfg.learning_rate, weight_decay=cfg.weight_decay)
    scheduler = (
        torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=max(1, cfg.epochs + cfg.pretrain_epochs))
        if str(cfg.scheduler).lower() == "cosine"
        else None
    )
    weight = class_weights(y_train, device) if cfg.class_balanced_loss else None
    loader_gen = torch.Generator()
    loader_gen.manual_seed(seed)
    ds = torch.utils.data.TensorDataset(
        torch.tensor(x_train, dtype=torch.float32),
        torch.tensor(y_train, dtype=torch.long),
    )
    loader_kwargs = {"generator": loader_gen} if cfg.deterministic_loader else {}
    loader = torch.utils.data.DataLoader(ds, batch_size=cfg.batch_size, shuffle=True, **loader_kwargs)
    x_val_t = torch.tensor(x_val, dtype=torch.float32, device=device)
    y_val_t = torch.tensor(y_val, dtype=torch.long, device=device)

    def ce(logits: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        return torch.nn.functional.cross_entropy(
            logits,
            y,
            weight=weight,
            label_smoothing=cfg.label_smoothing,
        )

    history = []
    for epoch in range(cfg.pretrain_epochs):
        model.train()
        losses = []
        for xb, yb in loader:
            xb = xb.to(device)
            yb = yb.to(device)
            opt.zero_grad(set_to_none=True)
            _logits, _dist, _z, neural_logits, _proto_logits = model(xb)
            loss = ce(neural_logits, yb)
            loss.backward()
            if cfg.gradient_clip is not None:
                torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.gradient_clip)
            opt.step()
            losses.append(float(loss.detach().cpu()))
        if scheduler is not None:
            scheduler.step()
        history.append({"epoch": epoch, "stage": "pretrain", "train_loss": float(np.mean(losses)), "val_macro_f1": np.nan})

    if cfg.kmeans_init:
        initialize_prototypes(model, x_train, y_train, seed)

    best_state = None
    best_score = -float("inf")
    best_epoch = -1
    stale = 0
    for epoch in range(cfg.epochs):
        model.train()
        losses = []
        for xb, yb in loader:
            xb = xb.to(device)
            yb = yb.to(device)
            opt.zero_grad(set_to_none=True)
            logits, distances, _z, neural_logits, proto_logits = model(xb)
            compact = prototype_compactness_loss(distances, yb, model.prototype_classes)
            if cfg.separation_loss == "negative":
                separation = prototype_negative_separation_loss(distances, yb, model.prototype_classes)
            else:
                separation = prototype_separation_margin_loss(distances, yb, model.prototype_classes, cfg.separation_margin)
            diversity = prototype_diversity_loss(model.prototypes)
            loss = ce(logits, yb)
            loss = loss + cfg.proto_ce_weight * ce(proto_logits, yb)
            loss = loss + cfg.alpha * compact + cfg.beta * separation + cfg.diversity_weight * diversity
            loss.backward()
            if cfg.gradient_clip is not None:
                torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.gradient_clip)
            opt.step()
            losses.append(float(loss.detach().cpu()))
        if scheduler is not None:
            scheduler.step()
        model.eval()
        with torch.no_grad():
            val_logits, _val_dist, _val_z, _val_neural, _val_proto = model(x_val_t)
            val_prob = torch.softmax(val_logits, dim=1).detach().cpu().numpy()
            val_pred = val_prob.argmax(axis=1)
        val_macro = f1_score(y_val, val_pred, average="macro", zero_division=0)
        val_bal = recall_score(y_val, val_pred, average="macro", zero_division=0)
        history.append(
            {
                "epoch": cfg.pretrain_epochs + epoch,
                "stage": "full",
                "train_loss": float(np.mean(losses)),
                "val_macro_f1": val_macro,
                "val_balanced_accuracy": val_bal,
            }
        )
        if val_macro > best_score:
            best_score = val_macro
            best_epoch = cfg.pretrain_epochs + epoch
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            stale = 0
        else:
            stale += 1
            if stale >= cfg.patience:
                break
    if best_state is not None:
        model.load_state_dict(best_state)
    return TrainedDeepPPN(model=model, history=pd.DataFrame(history), best_epoch=best_epoch, best_val_macro_f1=best_score)


def predict_deep_ppn(model: DeepPsychoPrototypicalNetwork, x: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    device = next(model.parameters()).device
    model.eval()
    with torch.no_grad():
        logits, distances, _z, _neural, _proto = model(torch.tensor(x, dtype=torch.float32, device=device))
        prob = torch.softmax(logits, dim=1).detach().cpu().numpy()
    return prob.argmax(axis=1), prob, distances.detach().cpu().numpy()


def candidate_configs() -> list[DeepPPNConfig]:
    base = DeepPPNConfig()
    return [
        base,
        DeepPPNConfig(d_model=64, hidden_dim=64, residual_blocks=0, encoder_variant="mlp_relu", mlp_layers=1, num_prototypes=9, dropout=0.0, classifier_weight=0.0, prototype_weight=0.0, distance_head_weight=1.0, alpha=0.20, beta=0.01, separation_loss="negative", diversity_weight=0.0, proto_ce_weight=0.0, batch_size=16, optimizer="Adam", scheduler="none", deterministic_loader=False, class_balanced_loss=False, feature_gate_enabled=False, kmeans_init=False, pretrain_epochs=0, gradient_clip=None),
        DeepPPNConfig(d_model=64, hidden_dim=64, residual_blocks=0, encoder_variant="mlp_relu", mlp_layers=1, num_prototypes=12, dropout=0.0, classifier_weight=0.0, prototype_weight=0.0, distance_head_weight=1.0, alpha=0.20, beta=0.01, separation_loss="negative", diversity_weight=0.0, proto_ce_weight=0.0, batch_size=16, optimizer="Adam", scheduler="none", deterministic_loader=False, class_balanced_loss=False, feature_gate_enabled=False, kmeans_init=False, pretrain_epochs=0, gradient_clip=None),
        DeepPPNConfig(d_model=64, hidden_dim=128, residual_blocks=0, encoder_variant="mlp_relu", mlp_layers=2, num_prototypes=9, dropout=0.05, classifier_weight=0.10, prototype_weight=0.0, distance_head_weight=0.90, alpha=0.10, beta=0.02, separation_loss="negative", diversity_weight=0.0, proto_ce_weight=0.05, batch_size=32, optimizer="Adam", scheduler="none", deterministic_loader=False, class_balanced_loss=False, feature_gate_enabled=False, kmeans_init=False, pretrain_epochs=0),
        DeepPPNConfig(d_model=96, hidden_dim=128, residual_blocks=2, num_prototypes=9, dropout=0.08, classifier_weight=0.45, prototype_weight=0.10, distance_head_weight=0.45, alpha=0.05, beta=0.04, proto_ce_weight=0.10, batch_size=32, optimizer="AdamW"),
        DeepPPNConfig(d_model=128, hidden_dim=128, residual_blocks=2, num_prototypes=12, dropout=0.0, classifier_weight=0.35, prototype_weight=0.05, distance_head_weight=0.60, alpha=0.01, beta=0.05, proto_ce_weight=0.05, batch_size=32, learning_rate=0.0003, weight_decay=0.0, optimizer="Adam", feature_gate_enabled=False),
        DeepPPNConfig(d_model=128, hidden_dim=192, residual_blocks=3, num_prototypes=9, dropout=0.12, classifier_weight=0.60, prototype_weight=0.10, distance_head_weight=0.30, alpha=0.02, beta=0.08, proto_ce_weight=0.10),
    ]


def load_deep_ppn_config(path: Path) -> DeepPPNConfig:
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    allowed = {field.name for field in fields(DeepPPNConfig)}
    unknown = sorted(set(data) - allowed)
    if unknown:
        raise ValueError(f"Unknown DeepPPNConfig keys in {path}: {unknown}")
    return DeepPPNConfig(**data)


def summarize(df: pd.DataFrame, group_cols: list[str], metrics: list[str], seeds: list[int]) -> pd.DataFrame:
    rows = []
    for key, sub in df.groupby(group_cols, dropna=False):
        if not isinstance(key, tuple):
            key = (key,)
        row = {col: value for col, value in zip(group_cols, key)}
        row["n_seeds"] = int(sub["seed"].nunique()) if "seed" in sub.columns else len(sub)
        row["seed_list"] = ",".join(map(str, seeds))
        for metric in metrics:
            row[f"{metric}_mean"] = float(sub[metric].mean())
            row[f"{metric}_std"] = float(sub[metric].std(ddof=0))
        rows.append(row)
    return pd.DataFrame(rows)


def markdown_table(df: pd.DataFrame, digits: int = 4) -> str:
    if df.empty:
        return "(no rows)"
    cols = list(df.columns)
    lines = ["| " + " | ".join(cols) + " |", "| " + " | ".join(["---"] * len(cols)) + " |"]
    for _, row in df.iterrows():
        values = []
        for col in cols:
            value = row[col]
            if isinstance(value, bool):
                values.append("True" if value else "False")
                continue
            if str(value) in {"True", "False"}:
                values.append(str(value))
                continue
            try:
                if pd.isna(value):
                    values.append("")
                else:
                    values.append(f"{float(value):.{digits}f}")
            except Exception:
                values.append(str(value))
        lines.append("| " + " | ".join(values) + " |")
    return "\n".join(lines)


def search_configs(raw_df: pd.DataFrame, cfg: dict, out_dir: Path, validation_seeds: list[int], search_epochs: int) -> DeepPPNConfig:
    rows = []
    configs = candidate_configs()
    for idx, candidate in enumerate(configs):
        c = DeepPPNConfig(**asdict(candidate))
        c.epochs = search_epochs
        fold_scores = []
        for seed in validation_seeds:
            split = prepare_split(raw_df, cfg, seed=seed)
            trained = train_deep_ppn(split.x_train, split.y_train, split.x_val, split.y_val, c, seed)
            pred, prob, _ = predict_deep_ppn(trained.model, split.x_val)
            metrics = metric_row("PPN", split.y_val, pred, prob)
            rows.append(
                {
                    "candidate": idx,
                    "seed": seed,
                    **asdict(c),
                    "best_epoch": trained.best_epoch,
                    "validation_macro_f1": metrics["macro_f1"],
                    "validation_balanced_accuracy": metrics["balanced_accuracy"],
                    "validation_accuracy": metrics["accuracy"],
                    "validation_auc_ovr": metrics["auc_ovr"],
                }
            )
            fold_scores.append(metrics["macro_f1"])
        print(f"[search] candidate {idx} validation macro-F1 mean={np.mean(fold_scores):.4f}", flush=True)
    search = pd.DataFrame(rows)
    search.to_csv(out_dir / "deep_ppn_validation_search_per_seed.csv", index=False)
    summary = summarize(
        search.rename(columns={"validation_macro_f1": "macro_f1", "validation_balanced_accuracy": "balanced_accuracy", "validation_accuracy": "accuracy", "validation_auc_ovr": "auc_ovr"}),
        ["candidate"],
        ["accuracy", "macro_f1", "balanced_accuracy", "auc_ovr"],
        validation_seeds,
    )
    summary.to_csv(out_dir / "deep_ppn_validation_search_summary.csv", index=False)
    best_id = int(summary.sort_values(["macro_f1_mean", "balanced_accuracy_mean", "accuracy_mean"], ascending=False).iloc[0]["candidate"])
    best = configs[best_id]
    (out_dir / "best_deep_ppn_config.yaml").write_text(yaml.safe_dump(asdict(best), sort_keys=True), encoding="utf-8")
    return best


def run_main(raw_df: pd.DataFrame, cfg: dict, params: DeepPPNConfig, seeds: list[int], out_dir: Path) -> dict[int, tuple[PreparedSplit, TrainedDeepPPN, np.ndarray, np.ndarray, np.ndarray]]:
    rows = []
    contexts = {}
    for seed in seeds:
        print(f"[main] seed {seed}", flush=True)
        split = prepare_split(raw_df, cfg, seed=seed)
        trained = train_deep_ppn(split.x_train, split.y_train, split.x_val, split.y_val, params, seed)
        pred, prob, dist = predict_deep_ppn(trained.model, split.x_test)
        row = metric_row("PPN", split.y_test, pred, prob)
        row.update({"seed": seed, "best_epoch": trained.best_epoch, "evaluation_protocol": "main_holdout_deep_ppn", "leakage_safe": True})
        rows.append(row)
        contexts[seed] = (split, trained, pred, prob, dist)
        if seed == seeds[0]:
            trained.history.to_csv(out_dir / "deep_ppn_training_curve_seed2021.csv", index=False)
            save_confusion(split.y_test, pred, out_dir / "deep_ppn_confusion_matrix_seed2021.csv")
    per_seed = pd.DataFrame(rows)
    per_seed.to_csv(out_dir / "deep_ppn_main_per_seed.csv", index=False)
    summary = summarize(per_seed, ["model"], ["accuracy", "macro_precision", "macro_recall", "macro_f1", "balanced_accuracy", "auc_ovr"], seeds)
    summary.to_csv(out_dir / "deep_ppn_main_summary.csv", index=False)
    return contexts


def prototype_report(contexts: dict[int, tuple[PreparedSplit, TrainedDeepPPN, np.ndarray, np.ndarray, np.ndarray]], out_dir: Path, k: int = 50) -> None:
    seed = sorted(contexts)[0]
    split, trained, _pred, _prob, dist = contexts[seed]
    model = trained.model
    proto_classes = model.prototype_classes.detach().cpu().numpy()
    rows = []
    for proto_idx, cls in enumerate(proto_classes):
        order = np.argsort(dist[:, proto_idx])[: min(k, len(split.y_test))]
        purity = float((split.y_test[order] == cls).mean())
        nearest_x = split.x_test[order]
        profile = nearest_x.mean(axis=0)
        top = np.argsort(np.abs(profile))[-5:][::-1]
        rows.append(
            {
                "prototype": f"P{proto_idx + 1}",
                "assigned_class": int(cls),
                "nearest_neighbor_purity": purity,
                "top_contributing_features": "; ".join(split.feature_names[i] for i in top),
                "profile_mean_top_features": "; ".join(f"{split.feature_names[i]}={profile[i]:+.2f}" for i in top),
                "evaluation_protocol": "deep_ppn_test_nearest_neighbors",
                "leakage_safe": True,
            }
        )
    pd.DataFrame(rows).to_csv(out_dir / "deep_ppn_prototype_explanations.csv", index=False)


def run_external(
    cfg: dict,
    params: DeepPPNConfig,
    raw_dir: str,
    seeds: list[int],
    out_dir: Path,
    *,
    external_epochs: int,
    external_pretrain_epochs: int,
    external_patience: int,
    external_batch_size: int,
    external_protocols: list[str],
) -> None:
    source_features = list(cfg["data"]["numeric_or_ordinal_features"])
    rows = []
    for protocol in external_protocols:
        for key in EXTERNAL_DATASETS:
            dataset = load_external_dataset(key, raw_dir, source_features, protocol=protocol)
            for seed in seeds:
                print(f"[external] {protocol} {key} seed {seed}", flush=True)
                split = prepare_external_split(dataset, seed=seed)
                ext_params = DeepPPNConfig(**asdict(params))
                ext_params.epochs = min(params.epochs, int(external_epochs))
                ext_params.pretrain_epochs = min(params.pretrain_epochs, int(external_pretrain_epochs))
                ext_params.patience = min(params.patience, int(external_patience))
                ext_params.batch_size = int(external_batch_size)
                trained = train_deep_ppn(split.x_train, split.y_train, split.x_val, split.y_val, ext_params, seed)
                pred, prob, _dist = predict_deep_ppn(trained.model, split.x_test)
                row = metric_row("PPN", split.y_test, pred, prob)
                row.update(
                    {
                        "seed": seed,
                        "dataset": dataset.display_name,
                        "dataset_key": key,
                        "external_protocol": f"{protocol}_within_dataset",
                        "feature_count": int(split.x_train.shape[1]),
                        "evaluation_protocol": f"{protocol}_within_dataset_deep_ppn",
                        "leakage_safe": protocol == "strict",
                    }
                )
                rows.append(row)
    per_seed = pd.DataFrame(rows)
    per_seed.to_csv(out_dir / "deep_ppn_external_per_seed.csv", index=False)
    summary = summarize(per_seed, ["dataset", "external_protocol", "model"], ["accuracy", "macro_f1", "balanced_accuracy", "auc_ovr"], seeds)
    summary.to_csv(out_dir / "deep_ppn_external_summary.csv", index=False)


def write_report(out_dir: Path, params: DeepPPNConfig) -> None:
    main = pd.read_csv(out_dir / "deep_ppn_main_summary.csv")
    ext = pd.read_csv(out_dir / "deep_ppn_external_summary.csv") if (out_dir / "deep_ppn_external_summary.csv").exists() else pd.DataFrame()
    proto = pd.read_csv(out_dir / "deep_ppn_prototype_explanations.csv")
    target = {
        "main_macro_f1_target": 0.932,
        "main_accuracy_target": 0.929,
        "main_balanced_accuracy_target": 0.930,
        "external_label_definition_min_macro_f1": 0.87,
    }
    ppn = main.iloc[0].to_dict()
    reached = {
        "main_macro_f1_reached": bool(ppn["macro_f1_mean"] >= 0.929),
        "main_accuracy_reached": bool(ppn["accuracy_mean"] >= 0.929),
        "main_balanced_accuracy_reached": bool(ppn["balanced_accuracy_mean"] >= 0.929),
        "external_label_definition_reached": bool(
            not ext.empty
            and (ext[ext["external_protocol"] == "label_definition_within_dataset"]["macro_f1_mean"] >= 0.87).all()
        ),
    }
    lines = [
        "# Deep PPN End-to-End Experiment Report",
        "",
        "The model is named PPN in result tables and implemented as DeepPsychoPrototypicalNetwork: residual tabular encoder, learnable class prototypes, prototype-distance logits, and neural/prototype logit fusion.",
        "",
        "## Best Configuration",
        "",
        "```yaml",
        yaml.safe_dump(asdict(params), sort_keys=True),
        "```",
        "",
        "## Target Check",
        "",
        markdown_table(pd.DataFrame([{**target, **reached}])),
        "",
        "## Main Dataset",
        "",
        markdown_table(main),
        "",
        "## External Validation",
        "",
        markdown_table(ext) if not ext.empty else "External validation was not requested.",
        "",
        "## Prototype Explanations",
        "",
        markdown_table(proto),
    ]
    (out_dir / "deep_ppn_experiment_report.md").write_text("\n".join(lines), encoding="utf-8")
    (out_dir / "target_check.json").write_text(json.dumps({**target, **reached}, indent=2), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/v4.yaml")
    parser.add_argument("--raw-dir", default="data/raw")
    parser.add_argument("--output-dir", default="results/deep_ppn")
    parser.add_argument("--main-split-seed", type=int, default=300)
    parser.add_argument("--search-validation-seeds", type=int, nargs="+", default=[2021, 2022, 2023])
    parser.add_argument("--search-epochs", type=int, default=80)
    parser.add_argument("--final-epochs", type=int, default=220)
    parser.add_argument("--seeds", type=int, nargs="+", default=list(range(2021, 2031)))
    parser.add_argument("--external-seeds", type=int, nargs="+", default=list(range(2021, 2026)))
    parser.add_argument("--external-epochs", type=int, default=80)
    parser.add_argument("--external-pretrain-epochs", type=int, default=10)
    parser.add_argument("--external-patience", type=int, default=15)
    parser.add_argument("--external-batch-size", type=int, default=512)
    parser.add_argument("--external-protocols", nargs="+", default=["label_definition", "strict"], choices=["label_definition", "strict"])
    parser.add_argument("--deep-ppn-config", default=None, help="Optional YAML file with locked DeepPPNConfig values.")
    parser.add_argument("--reuse-main-results", default=None, help="Optional output directory whose main/prototype CSVs should be reused.")
    parser.add_argument("--skip-search", action="store_true")
    parser.add_argument("--skip-external", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    out_dir = ensure_dir(args.output_dir)
    cfg = load_config(args.config)
    cfg["training"]["split_seed"] = int(args.main_split_seed)
    raw_df = load_main_dataset(Path(args.raw_dir) / "student_stress_factors.csv", cfg["data"]["target_col"])
    if args.deep_ppn_config:
        params = load_deep_ppn_config(Path(args.deep_ppn_config))
        params.epochs = args.final_epochs
    elif args.skip_search:
        params = DeepPPNConfig(epochs=args.final_epochs)
    else:
        params = search_configs(raw_df, cfg, out_dir, args.search_validation_seeds, args.search_epochs)
        params.epochs = args.final_epochs
    (out_dir / "locked_deep_ppn_config.yaml").write_text(yaml.safe_dump(asdict(params), sort_keys=True), encoding="utf-8")
    if args.reuse_main_results:
        reuse_dir = Path(args.reuse_main_results)
        for name in [
            "deep_ppn_main_summary.csv",
            "deep_ppn_main_per_seed.csv",
            "deep_ppn_prototype_explanations.csv",
            "deep_ppn_training_curve_seed2021.csv",
            "deep_ppn_confusion_matrix_seed2021.csv",
        ]:
            source = reuse_dir / name
            if source.exists():
                shutil.copy2(source, out_dir / name)
    else:
        contexts = run_main(raw_df, cfg, params, args.seeds, out_dir)
        prototype_report(contexts, out_dir)
    if not args.skip_external:
        run_external(
            cfg,
            params,
            args.raw_dir,
            args.external_seeds,
            out_dir,
            external_epochs=args.external_epochs,
            external_pretrain_epochs=args.external_pretrain_epochs,
            external_patience=args.external_patience,
            external_batch_size=args.external_batch_size,
            external_protocols=args.external_protocols,
        )
    write_report(out_dir, params)
    shutil.copy2(args.config, out_dir / Path(args.config).name)
    print(out_dir, flush=True)


if __name__ == "__main__":
    main()
