from __future__ import annotations

import warnings

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC

from ppn.models.ft_transformer import SimpleFTTransformerClassifier


def _maybe_xgboost(seed: int):
    try:
        from xgboost import XGBClassifier

        return XGBClassifier(
            n_estimators=200,
            max_depth=5,
            learning_rate=0.10,
            subsample=0.8,
            colsample_bytree=0.8,
            objective="multi:softprob",
            eval_metric="mlogloss",
            random_state=seed,
        )
    except Exception as exc:
        warnings.warn(f"XGBoost unavailable: {exc}")
        return None


def _maybe_lightgbm(seed: int):
    try:
        from lightgbm import LGBMClassifier

        return LGBMClassifier(
            n_estimators=200,
            num_leaves=31,
            max_depth=5,
            learning_rate=0.05,
            feature_fraction=0.8,
            random_state=seed,
            verbose=-1,
        )
    except Exception as exc:
        warnings.warn(f"LightGBM unavailable: {exc}")
        return None


def _maybe_catboost(seed: int):
    try:
        from catboost import CatBoostClassifier

        return CatBoostClassifier(
            iterations=400,
            depth=6,
            learning_rate=0.05,
            l2_leaf_reg=3,
            loss_function="MultiClass",
            random_seed=seed,
            verbose=False,
        )
    except Exception as exc:
        warnings.warn(f"CatBoost unavailable: {exc}")
        return None


def make_baselines(seed: int) -> dict[str, object]:
    models: dict[str, object] = {
        "Logistic Regression": LogisticRegression(C=1, penalty="l2", max_iter=5000, random_state=seed),
        "SVM": SVC(C=10, kernel="rbf", gamma="scale", probability=True, random_state=seed),
        "Random Forest": RandomForestClassifier(
            n_estimators=300,
            max_depth=10,
            min_samples_split=2,
            max_features="sqrt",
            random_state=seed,
        ),
        "MLP": MLPClassifier(
            hidden_layer_sizes=(128, 128),
            learning_rate_init=0.001,
            alpha=1e-5,
            batch_size=32,
            max_iter=500,
            random_state=seed,
            early_stopping=True,
        ),
        "FT-Transformer": SimpleFTTransformerClassifier(seed=seed),
    }
    optional = {
        "XGBoost": _maybe_xgboost(seed),
        "LightGBM": _maybe_lightgbm(seed),
        "CatBoost": _maybe_catboost(seed),
    }
    for name, model in optional.items():
        if model is not None:
            models[name] = model
    return models


def fit_predict_proba(model, x_train: np.ndarray, y_train: np.ndarray, x_test: np.ndarray):
    model.fit(x_train, y_train)
    pred = model.predict(x_test)
    if hasattr(model, "predict_proba"):
        prob = model.predict_proba(x_test)
    else:
        raise TypeError(f"Model {model} does not expose predict_proba.")
    return pred, prob
