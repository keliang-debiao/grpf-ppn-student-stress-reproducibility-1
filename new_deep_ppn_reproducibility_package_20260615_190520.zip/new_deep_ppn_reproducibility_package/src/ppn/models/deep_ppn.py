from __future__ import annotations

import random
from dataclasses import dataclass

import numpy as np
import torch
from torch import nn


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


class ResidualBlock(nn.Module):
    def __init__(self, dim: int, dropout: float) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.LayerNorm(dim),
            nn.Linear(dim, dim * 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dim * 2, dim),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.net(x)


class DeepPsychoPrototypicalNetwork(nn.Module):
    """Deep end-to-end PPN with a neural branch and a prototype-distance branch."""

    def __init__(
        self,
        input_dim: int,
        num_classes: int = 3,
        d_model: int = 96,
        hidden_dim: int = 128,
        residual_blocks: int = 3,
        mlp_layers: int = 1,
        num_prototypes: int = 9,
        dropout: float = 0.15,
        prototype_temperature: float = 1.0,
        classifier_weight: float = 0.65,
        prototype_weight: float = 0.35,
        distance_head_weight: float = 0.0,
        normalize_embeddings: bool = False,
        feature_gate_enabled: bool = True,
        encoder_variant: str = "residual",
    ) -> None:
        super().__init__()
        self.num_classes = int(num_classes)
        self.num_prototypes = int(num_prototypes)
        self.prototype_temperature = max(float(prototype_temperature), 1e-6)
        self.classifier_weight = float(classifier_weight)
        self.prototype_weight = float(prototype_weight)
        self.distance_head_weight = float(distance_head_weight)
        self.normalize_embeddings = bool(normalize_embeddings)
        self.feature_gate_enabled = bool(feature_gate_enabled)
        self.encoder_variant = str(encoder_variant)

        self.feature_gate = nn.Sequential(
            nn.Linear(input_dim, input_dim),
            nn.Sigmoid(),
        )
        if self.encoder_variant == "mlp_relu":
            layers: list[nn.Module] = []
            prev_dim = input_dim
            for _ in range(max(1, int(mlp_layers))):
                layers.extend([nn.Linear(prev_dim, hidden_dim), nn.ReLU(), nn.Dropout(dropout)])
                prev_dim = hidden_dim
            layers.append(nn.Linear(prev_dim, d_model))
            self.encoder = nn.Sequential(*layers)
        elif self.encoder_variant == "residual":
            self.input = nn.Sequential(
                nn.Linear(input_dim, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.GELU(),
                nn.Dropout(dropout),
            )
            self.blocks = nn.Sequential(*[ResidualBlock(hidden_dim, dropout) for _ in range(int(residual_blocks))])
            self.project = nn.Sequential(
                nn.LayerNorm(hidden_dim),
                nn.Linear(hidden_dim, d_model),
                nn.LayerNorm(d_model),
            )
        else:
            raise ValueError(f"Unknown encoder_variant: {encoder_variant}")
        self.classifier = nn.Sequential(
            nn.Linear(d_model, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, num_classes),
        )
        self.prototypes = nn.Parameter(torch.randn(num_prototypes, d_model) * 0.05)
        self.distance_classifier = nn.Linear(num_prototypes, num_classes)
        per_class = int(np.ceil(num_prototypes / num_classes))
        proto_classes = torch.arange(num_classes).repeat_interleave(per_class)[:num_prototypes]
        self.register_buffer("prototype_classes", proto_classes.long())
        self.prototype_bias = nn.Parameter(torch.zeros(num_classes))

    def encode(self, x: torch.Tensor) -> torch.Tensor:
        gated = x * (1.0 + self.feature_gate(x)) if self.feature_gate_enabled else x
        if self.encoder_variant == "mlp_relu":
            z = self.encoder(gated)
        else:
            h = self.input(gated)
            h = self.blocks(h)
            z = self.project(h)
        if self.normalize_embeddings:
            z = torch.nn.functional.normalize(z, p=2, dim=1)
        return z

    def distances(self, z: torch.Tensor) -> torch.Tensor:
        prototypes = self.prototypes
        if self.normalize_embeddings:
            prototypes = torch.nn.functional.normalize(prototypes, p=2, dim=1)
        return torch.cdist(z, prototypes, p=2).pow(2)

    def prototype_logits(self, distances: torch.Tensor) -> torch.Tensor:
        logits = []
        for cls in range(self.num_classes):
            cls_d = distances[:, self.prototype_classes == cls]
            soft_min = -torch.logsumexp(-cls_d / self.prototype_temperature, dim=1) * self.prototype_temperature
            logits.append(-soft_min / self.prototype_temperature + self.prototype_bias[cls])
        return torch.stack(logits, dim=1)

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        z = self.encode(x)
        d = self.distances(z)
        neural_logits = self.classifier(z)
        class_proto_logits = self.prototype_logits(d)
        distance_head_logits = self.distance_classifier(-d)
        proto_logits = self.prototype_weight * class_proto_logits + self.distance_head_weight * distance_head_logits
        logits = self.classifier_weight * neural_logits + proto_logits
        return logits, d, z, neural_logits, proto_logits


class DeepPsychoPrototypicalEnsemble(nn.Module):
    def __init__(self, models: list[DeepPsychoPrototypicalNetwork]) -> None:
        super().__init__()
        if not models:
            raise ValueError("DeepPsychoPrototypicalEnsemble requires at least one model.")
        self.models = nn.ModuleList(models)
        self.num_classes = models[0].num_classes
        proto_classes = torch.cat([model.prototype_classes.detach().cpu() for model in models])
        self.register_buffer("prototype_classes", proto_classes.long())

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        probs = []
        distances = []
        embeddings = []
        neural_probs = []
        proto_probs = []
        for model in self.models:
            logits, dist, z, neural_logits, proto_logits = model(x)
            probs.append(torch.softmax(logits, dim=1))
            distances.append(dist)
            embeddings.append(z)
            neural_probs.append(torch.softmax(neural_logits, dim=1))
            proto_probs.append(torch.softmax(proto_logits, dim=1))
        prob = torch.stack(probs, dim=0).mean(dim=0).clamp_min(1e-8)
        neural_prob = torch.stack(neural_probs, dim=0).mean(dim=0).clamp_min(1e-8)
        proto_prob = torch.stack(proto_probs, dim=0).mean(dim=0).clamp_min(1e-8)
        return (
            torch.log(prob),
            torch.cat(distances, dim=1),
            embeddings[0],
            torch.log(neural_prob),
            torch.log(proto_prob),
        )


def prototype_compactness_loss(
    distances: torch.Tensor,
    y: torch.Tensor,
    prototype_classes: torch.Tensor,
) -> torch.Tensor:
    same = prototype_classes.unsqueeze(0) == y.unsqueeze(1)
    return distances.masked_fill(~same, float("inf")).min(dim=1).values.mean()


def prototype_separation_margin_loss(
    distances: torch.Tensor,
    y: torch.Tensor,
    prototype_classes: torch.Tensor,
    margin: float,
) -> torch.Tensor:
    same = prototype_classes.unsqueeze(0) == y.unsqueeze(1)
    diff = ~same
    nearest_same = distances.masked_fill(~same, float("inf")).min(dim=1).values
    nearest_diff = distances.masked_fill(~diff, float("inf")).min(dim=1).values
    return torch.relu(float(margin) + nearest_same - nearest_diff).mean()


def prototype_negative_separation_loss(
    distances: torch.Tensor,
    y: torch.Tensor,
    prototype_classes: torch.Tensor,
) -> torch.Tensor:
    diff = prototype_classes.unsqueeze(0) != y.unsqueeze(1)
    return -distances.masked_fill(~diff, float("inf")).min(dim=1).values.mean()


def prototype_diversity_loss(prototypes: torch.Tensor) -> torch.Tensor:
    if prototypes.shape[0] < 2:
        return torch.zeros((), dtype=prototypes.dtype, device=prototypes.device)
    normalized = torch.nn.functional.normalize(prototypes, p=2, dim=1)
    similarity = normalized @ normalized.T
    eye = torch.eye(similarity.shape[0], dtype=torch.bool, device=similarity.device)
    return similarity.masked_fill(eye, 0.0).pow(2).mean()


@dataclass
class DeepPPNTrainResult:
    model: DeepPsychoPrototypicalNetwork
    history: object
    best_epoch: int
    best_val_macro_f1: float
