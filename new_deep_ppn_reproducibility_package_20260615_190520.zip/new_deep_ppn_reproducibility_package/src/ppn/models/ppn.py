from __future__ import annotations

import random
from dataclasses import dataclass

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


class PsychoPrototypicalNetwork(nn.Module):
    def __init__(
        self,
        input_dim: int,
        num_classes: int = 3,
        d_model: int = 64,
        hidden_dim: int = 128,
        hidden_layers: int = 1,
        num_prototypes: int = 6,
        dropout: float = 0.1,
        head_type: str = "linear",
        distance_reduction: str = "mean",
        distance_temperature: float = 1.0,
        normalize_embeddings: bool = False,
    ) -> None:
        super().__init__()
        self.num_classes = num_classes
        self.num_prototypes = num_prototypes
        self.head_type = head_type
        self.distance_reduction = distance_reduction
        self.distance_temperature = max(float(distance_temperature), 1e-6)
        self.normalize_embeddings = bool(normalize_embeddings)
        layers: list[nn.Module] = []
        prev_dim = input_dim
        for _ in range(max(1, int(hidden_layers))):
            layers.extend([nn.Linear(prev_dim, hidden_dim), nn.ReLU(), nn.Dropout(dropout)])
            prev_dim = hidden_dim
        layers.append(nn.Linear(prev_dim, d_model))
        self.encoder = nn.Sequential(*layers)
        self.prototypes = nn.Parameter(torch.randn(num_prototypes, d_model) * 0.05)
        per_class = int(np.ceil(num_prototypes / num_classes))
        proto_classes = torch.arange(num_classes).repeat_interleave(per_class)[:num_prototypes]
        self.register_buffer("prototype_classes", proto_classes.long())
        if self.head_type == "linear":
            self.classifier = nn.Linear(num_prototypes, num_classes)
        elif self.head_type in {"class_distance", "class_similarity"}:
            self.class_bias = nn.Parameter(torch.zeros(num_classes))
        else:
            raise ValueError(f"Unknown PPN head_type: {head_type}")

    def encode(self, x: torch.Tensor) -> torch.Tensor:
        z = self.encoder(x)
        if self.normalize_embeddings:
            z = torch.nn.functional.normalize(z, p=2, dim=1)
        return z

    def distances(self, z: torch.Tensor) -> torch.Tensor:
        prototypes = self.prototypes
        if self.normalize_embeddings:
            prototypes = torch.nn.functional.normalize(prototypes, p=2, dim=1)
        return torch.cdist(z, prototypes, p=2).pow(2)

    def distance_logits(self, distances: torch.Tensor) -> torch.Tensor:
        if self.head_type == "linear":
            return self.classifier(-distances)
        class_logits = []
        for cls in range(self.num_classes):
            cls_distances = distances[:, self.prototype_classes == cls]
            if self.distance_reduction == "min":
                value = cls_distances.min(dim=1).values
            elif self.distance_reduction == "softmin":
                value = -torch.logsumexp(-cls_distances / self.distance_temperature, dim=1) * self.distance_temperature
            else:
                value = cls_distances.mean(dim=1)
            class_logits.append(-value / self.distance_temperature + self.class_bias[cls])
        return torch.stack(class_logits, dim=1)

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        z = self.encode(x)
        d = self.distances(z)
        logits = self.distance_logits(d)
        return logits, d, z


class PsychoPrototypicalEnsemble(nn.Module):
    def __init__(self, models: list[PsychoPrototypicalNetwork]) -> None:
        super().__init__()
        if not models:
            raise ValueError("PsychoPrototypicalEnsemble requires at least one model.")
        self.models = nn.ModuleList(models)
        self.num_classes = models[0].num_classes
        proto_classes = torch.cat([model.prototype_classes.detach().cpu() for model in models])
        self.register_buffer("prototype_classes", proto_classes.long())

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        probs = []
        distances = []
        embeddings = []
        for model in self.models:
            logits, dist, z = model(x)
            probs.append(torch.softmax(logits, dim=1))
            distances.append(dist)
            embeddings.append(z)
        mean_prob = torch.stack(probs, dim=0).mean(dim=0).clamp_min(1e-8)
        logits = torch.log(mean_prob)
        return logits, torch.cat(distances, dim=1), embeddings[0]


def prototype_losses(
    distances: torch.Tensor,
    y: torch.Tensor,
    prototype_classes: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor]:
    same = prototype_classes.unsqueeze(0) == y.unsqueeze(1)
    diff = ~same
    compact = distances.masked_fill(~same, float("inf")).min(dim=1).values.mean()
    separation = -distances.masked_fill(~diff, float("inf")).min(dim=1).values.mean()
    return compact, separation


def prototype_diversity_loss(prototypes: torch.Tensor) -> torch.Tensor:
    if prototypes.shape[0] < 2:
        return torch.zeros((), dtype=prototypes.dtype, device=prototypes.device)
    normalized = torch.nn.functional.normalize(prototypes, p=2, dim=1)
    similarity = normalized @ normalized.T
    eye = torch.eye(similarity.shape[0], dtype=torch.bool, device=similarity.device)
    return similarity.masked_fill(eye, 0.0).pow(2).mean()


@dataclass
class TrainResult:
    model: PsychoPrototypicalNetwork
    best_val_loss: float


def train_ppn(
    x_train: np.ndarray,
    y_train: np.ndarray,
    x_val: np.ndarray,
    y_val: np.ndarray,
    cfg: dict,
    seed: int,
) -> TrainResult:
    set_seed(seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    ppn_cfg = cfg["ppn"]
    model = PsychoPrototypicalNetwork(
        input_dim=x_train.shape[1],
        num_classes=3,
        d_model=int(ppn_cfg["d_model"]),
        hidden_dim=int(ppn_cfg["hidden_dim"]),
        hidden_layers=int(ppn_cfg.get("hidden_layers", 1)),
        num_prototypes=int(ppn_cfg["num_prototypes"]),
        dropout=float(ppn_cfg["dropout"]),
        head_type=str(ppn_cfg.get("head_type", "linear")),
        distance_reduction=str(ppn_cfg.get("distance_reduction", "mean")),
        distance_temperature=float(ppn_cfg.get("distance_temperature", 1.0)),
        normalize_embeddings=bool(ppn_cfg.get("normalize_embeddings", False)),
    ).to(device)
    optimizer_name = str(ppn_cfg.get("optimizer", "AdamW")).lower()
    optimizer_cls = torch.optim.Adam if optimizer_name == "adam" else torch.optim.AdamW
    opt = optimizer_cls(
        model.parameters(),
        lr=float(ppn_cfg["learning_rate"]),
        weight_decay=float(ppn_cfg["weight_decay"]),
    )
    ce = nn.CrossEntropyLoss(label_smoothing=float(ppn_cfg.get("label_smoothing", 0.0)))
    batch_size = int(cfg["training"]["batch_size"])
    ds = TensorDataset(
        torch.tensor(x_train, dtype=torch.float32),
        torch.tensor(y_train, dtype=torch.long),
    )
    loader = DataLoader(ds, batch_size=batch_size, shuffle=True)
    x_val_t = torch.tensor(x_val, dtype=torch.float32, device=device)
    y_val_t = torch.tensor(y_val, dtype=torch.long, device=device)
    best_state = None
    best_loss = float("inf")
    patience = int(cfg["training"]["early_stopping_patience"])
    stale = 0
    for _epoch in range(int(cfg["training"]["epochs"])):
        model.train()
        for xb, yb in loader:
            xb = xb.to(device)
            yb = yb.to(device)
            opt.zero_grad(set_to_none=True)
            logits, distances, _ = model(xb)
            compact, separation = prototype_losses(distances, yb, model.prototype_classes)
            loss = ce(logits, yb) + float(ppn_cfg["alpha"]) * compact + float(ppn_cfg["beta"]) * separation
            loss = loss + float(ppn_cfg.get("diversity_weight", 0.0)) * prototype_diversity_loss(model.prototypes)
            loss.backward()
            clip = ppn_cfg.get("gradient_clip")
            if clip is not None:
                torch.nn.utils.clip_grad_norm_(model.parameters(), float(clip))
            opt.step()
        model.eval()
        with torch.no_grad():
            logits, distances, _ = model(x_val_t)
            compact, separation = prototype_losses(distances, y_val_t, model.prototype_classes)
            val_loss = ce(logits, y_val_t) + float(ppn_cfg["alpha"]) * compact + float(ppn_cfg["beta"]) * separation
            val_loss = val_loss + float(ppn_cfg.get("diversity_weight", 0.0)) * prototype_diversity_loss(model.prototypes)
            val_loss_f = float(val_loss.detach().cpu())
        if val_loss_f < best_loss:
            best_loss = val_loss_f
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            stale = 0
        else:
            stale += 1
            if stale >= patience:
                break
    if best_state is not None:
        model.load_state_dict(best_state)
    return TrainResult(model=model, best_val_loss=best_loss)


def predict_ppn(model: PsychoPrototypicalNetwork, x: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    device = next(model.parameters()).device
    model.eval()
    with torch.no_grad():
        logits, distances, z = model(torch.tensor(x, dtype=torch.float32, device=device))
        probs = torch.softmax(logits, dim=1).detach().cpu().numpy()
        pred = probs.argmax(axis=1)
    return pred, probs, distances.detach().cpu().numpy()
