from __future__ import annotations

import json
import shutil
from dataclasses import dataclass
from pathlib import Path
from urllib.request import Request, urlopen

import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from ppn.data import normalize_columns


STRESS_ITEMS_42 = [1, 6, 8, 11, 12, 14, 18, 22, 27, 29, 32, 33, 35, 39]
ANXIETY_ITEMS_42 = [2, 4, 7, 9, 15, 19, 20, 23, 25, 28, 30, 36, 40, 41]
DEPRESSION_ITEMS_42 = [3, 5, 10, 13, 16, 17, 21, 24, 26, 31, 34, 37, 38, 42]


@dataclass(frozen=True)
class KaggleDataset:
    key: str
    display_name: str
    slug: str
    target_subdir: str


@dataclass
class ExternalDataset:
    key: str
    display_name: str
    y: np.ndarray
    within_features: pd.DataFrame
    source_mapped_features: pd.DataFrame
    target_description: str
    feature_description: str


@dataclass
class ExternalSplit:
    x_train: np.ndarray
    y_train: np.ndarray
    x_val: np.ndarray
    y_val: np.ndarray
    x_test: np.ndarray
    y_test: np.ndarray
    feature_names: list[str]


EXTERNAL_DATASETS = {
    "student_mental_health": KaggleDataset(
        key="student_mental_health",
        display_name="Student Mental Health Dataset",
        slug="junnn0126/university-students-mental-health",
        target_subdir="student_mental_health",
    ),
    "dass21": KaggleDataset(
        key="dass21",
        display_name="DASS-21 Response Dataset",
        slug="mendeley:br82d4xkj7",
        target_subdir="dass21",
    ),
    "medical_student_mental_health": KaggleDataset(
        key="medical_student_mental_health",
        display_name="Medical Student Mental Health Dataset",
        slug="thedevastator/medical-student-mental-health",
        target_subdir="medical_student_mental_health",
    ),
}


MAIN_DATASET = KaggleDataset(
    key="main_student_stress",
    display_name="Student Stress Factors: A Comprehensive Analysis",
    slug="rxnach/student-stress-factors-a-comprehensive-analysis",
    target_subdir=".",
)


def download_dataset_files(raw_dir: str | Path, include_main: bool = True) -> pd.DataFrame:
    try:
        import kagglehub
    except Exception as exc:
        raise SystemExit("Install kagglehub or run with the project requirements installed.") from exc

    raw_dir = Path(raw_dir)
    raw_dir.mkdir(parents=True, exist_ok=True)
    copied_rows = []
    datasets = list(EXTERNAL_DATASETS.values())
    if include_main:
        datasets = [MAIN_DATASET] + datasets
    for spec in datasets:
        if spec.slug.startswith("mendeley:"):
            copied_rows.extend(_download_mendeley_files(spec, raw_dir))
            continue
        source_dir = Path(kagglehub.dataset_download(spec.slug))
        target_dir = raw_dir if spec.key == MAIN_DATASET.key else raw_dir / "external" / spec.target_subdir
        target_dir.mkdir(parents=True, exist_ok=True)
        for source_file in sorted(source_dir.rglob("*")):
            if not source_file.is_file() or source_file.suffix.lower() not in {".csv", ".txt"}:
                continue
            target_name = "student_stress_factors.csv" if spec.key == MAIN_DATASET.key and source_file.suffix.lower() == ".csv" else source_file.name
            target_file = target_dir / target_name
            shutil.copy2(source_file, target_file)
            copied_rows.append(
                {
                    "dataset": spec.key,
                    "display_name": spec.display_name,
                    "slug": spec.slug,
                    "source_file": str(source_file),
                    "target_file": str(target_file),
                }
            )
    return pd.DataFrame(copied_rows)


def _download_mendeley_files(spec: KaggleDataset, raw_dir: Path) -> list[dict]:
    dataset_id = spec.slug.split(":", 1)[1]
    target_dir = raw_dir / "external" / spec.target_subdir
    target_dir.mkdir(parents=True, exist_ok=True)
    request = Request(
        f"https://data.mendeley.com/public-api/datasets/{dataset_id}",
        headers={"User-Agent": "Mozilla/5.0"},
    )
    with urlopen(request) as response:
        metadata = json.loads(response.read().decode("utf-8"))
    rows = []
    for file_info in metadata["files"]:
        filename = file_info["filename"]
        if Path(filename).suffix.lower() not in {".csv", ".txt"}:
            continue
        target_file = target_dir / filename
        file_request = Request(file_info["content_details"]["download_url"], headers={"User-Agent": "Mozilla/5.0"})
        with urlopen(file_request) as response, target_file.open("wb") as out_file:
            shutil.copyfileobj(response, out_file)
        rows.append(
            {
                "dataset": spec.key,
                "display_name": spec.display_name,
                "slug": spec.slug,
                "source_file": file_info["content_details"]["download_url"],
                "target_file": str(target_file),
            }
        )
    return rows


def load_external_dataset(
    key: str,
    raw_dir: str | Path,
    source_features: list[str],
    protocol: str = "strict",
) -> ExternalDataset:
    if protocol == "label_definition":
        if key == "student_mental_health":
            return _load_student_mental_health_label_definition(raw_dir, source_features)
        if key == "dass21":
            return _load_dass21_label_definition(raw_dir, source_features)
        if key == "medical_student_mental_health":
            return _load_medical_student_mental_health_label_definition(raw_dir, source_features)
        raise KeyError(f"Unknown external dataset: {key}")
    if protocol != "strict":
        raise ValueError(f"Unknown external dataset protocol: {protocol}")
    if key == "student_mental_health":
        return _load_student_mental_health(raw_dir, source_features)
    if key == "dass21":
        return _load_dass21(raw_dir, source_features)
    if key == "medical_student_mental_health":
        return _load_medical_student_mental_health(raw_dir, source_features)
    raise KeyError(f"Unknown external dataset: {key}")


def prepare_external_split(dataset: ExternalDataset, seed: int, test_size: float = 0.2, val_size: float = 0.2) -> ExternalSplit:
    indices = np.arange(len(dataset.y))
    train_full_idx, test_idx = train_test_split(
        indices,
        test_size=test_size,
        random_state=seed,
        stratify=dataset.y,
    )
    train_idx, val_idx = train_test_split(
        train_full_idx,
        test_size=val_size,
        random_state=seed,
        stratify=dataset.y[train_full_idx],
    )
    features = dataset.within_features
    imputer = SimpleImputer(strategy="median")
    scaler = StandardScaler()
    x_train = scaler.fit_transform(imputer.fit_transform(features.iloc[train_idx].to_numpy(dtype=float)))
    x_val = scaler.transform(imputer.transform(features.iloc[val_idx].to_numpy(dtype=float)))
    x_test = scaler.transform(imputer.transform(features.iloc[test_idx].to_numpy(dtype=float)))
    return ExternalSplit(
        x_train=x_train,
        y_train=dataset.y[train_idx],
        x_val=x_val,
        y_val=dataset.y[val_idx],
        x_test=x_test,
        y_test=dataset.y[test_idx],
        feature_names=list(features.columns),
    )


def source_model_matrix(dataset: ExternalDataset, source_features: list[str], imputer: SimpleImputer, scaler: StandardScaler) -> np.ndarray:
    mapped = dataset.source_mapped_features.reindex(columns=source_features)
    return scaler.transform(imputer.transform(mapped.to_numpy(dtype=float)))


def class_counts(y: np.ndarray) -> dict[str, int]:
    return {f"class_{cls}": int((y == cls).sum()) for cls in [0, 1, 2]}


def _load_student_mental_health(raw_dir: str | Path, source_features: list[str]) -> ExternalDataset:
    path = Path(raw_dir) / "external" / "student_mental_health" / "mentalhealth_dataset.csv"
    df = normalize_columns(pd.read_csv(path))
    y = df["studystresslevel"].map(lambda value: 0 if value <= 2 else (1 if value == 3 else 2)).to_numpy(dtype=int)
    within = _numeric_and_dummies(
        df,
        exclude=["timestamp", "studystresslevel"],
        categorical=["gender", "yearofstudy", "course"],
    )
    mapped = _blank_source_frame(len(df), source_features)
    mapped["anxiety_level"] = _binary_to_range(df["anxiety"], 21.0)
    mapped["mental_health_history"] = pd.to_numeric(df["specialisttreatment"], errors="coerce")
    mapped["depression"] = _binary_to_range(df["depression"], 27.0)
    mapped["headache"] = _range_to_range(df["symptomfrequency_last7days"], 0.0, 7.0, 0.0, 5.0)
    mapped["sleep_quality"] = _range_to_range(df["sleepquality"], 1.0, 5.0, 1.0, 5.0)
    mapped["breathing_problem"] = _binary_to_range(df["panicattack"], 5.0)
    mapped["academic_performance"] = _range_to_range(df["cgpa"], 2.0, 4.0, 0.0, 5.0)
    mapped["study_load"] = _range_to_range(df["studyhoursperweek"], 0.0, 20.0, 0.0, 5.0)
    mapped["social_support"] = _binary_to_range(df["hasmentalhealthsupport"], 3.0)
    return ExternalDataset(
        key="student_mental_health",
        display_name=EXTERNAL_DATASETS["student_mental_health"].display_name,
        y=y,
        within_features=within,
        source_mapped_features=mapped,
        target_description="StudyStressLevel collapsed as 1-2=low, 3=moderate, 4-5=high.",
        feature_description="Within-dataset features exclude StudyStressLevel; source-transfer features map available constructs to the manuscript 20-feature schema.",
    )


def _load_student_mental_health_label_definition(raw_dir: str | Path, source_features: list[str]) -> ExternalDataset:
    path = Path(raw_dir) / "external" / "student_mental_health" / "mentalhealth_dataset.csv"
    df = normalize_columns(pd.read_csv(path))
    y = df["studystresslevel"].map(lambda value: 0 if value <= 2 else (1 if value == 3 else 2)).to_numpy(dtype=int)
    within = _numeric_and_dummies(
        df,
        exclude=["timestamp"],
        categorical=["gender", "yearofstudy", "course"],
    )
    mapped = _blank_source_frame(len(df), source_features)
    return ExternalDataset(
        key="student_mental_health",
        display_name=EXTERNAL_DATASETS["student_mental_health"].display_name,
        y=y,
        within_features=within,
        source_mapped_features=mapped,
        target_description="Label-definition protocol: StudyStressLevel is both the source of the target and included among candidate predictors.",
        feature_description="Non-strict protocol for numeric reproducibility only; this is not leakage-free external validation.",
    )


def _load_dass21(raw_dir: str | Path, source_features: list[str]) -> ExternalDataset:
    path = Path(raw_dir) / "external" / "dass21" / "DASS.csv"
    if not path.exists():
        return _load_dass42_fallback(raw_dir, source_features)
    df = normalize_columns(pd.read_csv(path))
    y = df["stress_level"].map(lambda value: 0 if value <= 2 else (1 if value == 3 else 2)).to_numpy(dtype=int)

    anxiety_items = [f"q3_{i}_a{i - 7}" for i in range(8, 15)]
    depression_items = [f"q3_{i}_d{i - 14}" for i in range(15, 22)]
    demographic = ["q1_1", "q1_2", "q1_3", "q1_4", "q1_5", "q1_6"]
    within = df[[c for c in anxiety_items + depression_items + ["anxiety_score", "anxiety_level", "depression_score", "depression_level"] + demographic if c in df.columns]]
    within = within.apply(pd.to_numeric, errors="coerce")

    mapped = _blank_source_frame(len(df), source_features)
    mapped["anxiety_level"] = _range_to_range(df["anxiety_score"], 0.0, 21.0, 0.0, 21.0)
    mapped["depression"] = _range_to_range(df["depression_score"], 0.0, 21.0, 0.0, 27.0)
    mapped["sleep_quality"] = _range_to_range(1.0 - pd.to_numeric(df["q1_6"], errors="coerce"), 0.0, 1.0, 0.0, 5.0)
    return ExternalDataset(
        key="dass21",
        display_name=EXTERNAL_DATASETS["dass21"].display_name,
        y=y,
        within_features=within,
        source_mapped_features=mapped,
        target_description="Mendeley DASS-21 Stress_Level collapsed as 1-2=low, 3=moderate, 4-5=high.",
        feature_description="Within-dataset features exclude DASS-21 stress items and use anxiety/depression items plus demographic/sleep fields.",
    )


def _load_dass21_label_definition(raw_dir: str | Path, source_features: list[str]) -> ExternalDataset:
    path = Path(raw_dir) / "external" / "dass21" / "DASS.csv"
    if not path.exists():
        raise FileNotFoundError(f"Missing Mendeley DASS-21 file: {path}")
    df = normalize_columns(pd.read_csv(path))
    y = df["stress_level"].map(lambda value: 0 if value <= 2 else (1 if value == 3 else 2)).to_numpy(dtype=int)
    within = df.select_dtypes(include=[np.number]).drop(columns=["stress_level"])
    mapped = _blank_source_frame(len(df), source_features)
    return ExternalDataset(
        key="dass21",
        display_name=EXTERNAL_DATASETS["dass21"].display_name,
        y=y,
        within_features=within.apply(pd.to_numeric, errors="coerce"),
        source_mapped_features=mapped,
        target_description="Label-definition protocol: Stress_Level is predicted from DASS-21 stress items and Stress_Score plus other fields.",
        feature_description="Non-strict protocol for numeric reproducibility only; stress items/score define the target severity label.",
    )


def _load_dass42_fallback(raw_dir: str | Path, source_features: list[str]) -> ExternalDataset:
    path = Path(raw_dir) / "external" / "dass21" / "data.csv"
    df = normalize_columns(pd.read_csv(path, sep="\t"))
    stress_score = _dass_score(df, STRESS_ITEMS_42)
    anxiety_score = _dass_score(df, ANXIETY_ITEMS_42)
    depression_score = _dass_score(df, DEPRESSION_ITEMS_42)
    valid = df["age"].between(13, 80) & stress_score.notna()
    df = df.loc[valid].reset_index(drop=True)
    stress_score = stress_score.loc[valid].reset_index(drop=True)
    anxiety_score = anxiety_score.loc[valid].reset_index(drop=True)
    depression_score = depression_score.loc[valid].reset_index(drop=True)
    y = pd.cut(stress_score, bins=[-np.inf, 18, 25, np.inf], labels=[0, 1, 2]).to_numpy(dtype=int)

    non_stress_items = [f"q{i}a" for i in sorted(set(ANXIETY_ITEMS_42 + DEPRESSION_ITEMS_42))]
    extra_numeric = [
        "education",
        "urban",
        "gender",
        "engnat",
        "age",
        "screensize",
        "hand",
        "religion",
        "orientation",
        "race",
        "voted",
        "married",
        "familysize",
    ]
    tipi = [f"tipi{i}" for i in range(1, 11)]
    vcl = [f"vcl{i}" for i in range(1, 17)]
    within = df[[c for c in non_stress_items + tipi + vcl + extra_numeric if c in df.columns]].apply(pd.to_numeric, errors="coerce")

    mapped = _blank_source_frame(len(df), source_features)
    mapped["anxiety_level"] = _range_to_range(anxiety_score, 0.0, 42.0, 0.0, 21.0)
    mapped["depression"] = _range_to_range(depression_score, 0.0, 42.0, 0.0, 27.0)
    if {"tipi4", "tipi9"}.issubset(df.columns):
        emotional_stability = (8.0 - pd.to_numeric(df["tipi4"], errors="coerce")) + pd.to_numeric(df["tipi9"], errors="coerce")
        mapped["self_esteem"] = _range_to_range(emotional_stability, 2.0, 14.0, 0.0, 30.0)
    if "q4a" in df.columns:
        mapped["breathing_problem"] = _range_to_range(pd.to_numeric(df["q4a"], errors="coerce") - 1.0, 0.0, 3.0, 0.0, 5.0)
    return ExternalDataset(
        key="dass21",
        display_name=EXTERNAL_DATASETS["dass21"].display_name,
        y=y,
        within_features=within,
        source_mapped_features=mapped,
        target_description="DASS stress subscale from the 42-item response file, collapsed as 0-18=low, 19-25=moderate, >=26=high.",
        feature_description="Within-dataset features exclude DASS stress items and use anxiety/depression items plus demographics/personality checks.",
    )


def _load_medical_student_mental_health(raw_dir: str | Path, source_features: list[str]) -> ExternalDataset:
    path = Path(raw_dir) / "external" / "medical_student_mental_health" / "Data Carrard et al. 2022 MedTeach.csv"
    df = normalize_columns(pd.read_csv(path))
    stress_proxy = _z(df["mbi_ex"]) + _z(df["mbi_cy"])
    low_cut, high_cut = stress_proxy.quantile([1 / 3, 2 / 3]).to_list()
    y = pd.cut(stress_proxy, bins=[-np.inf, low_cut, high_cut, np.inf], labels=[0, 1, 2]).to_numpy(dtype=int)
    within = _numeric_and_dummies(
        df,
        exclude=["id", "mbi_ex", "mbi_cy"],
        categorical=[],
    )
    mapped = _blank_source_frame(len(df), source_features)
    mapped["anxiety_level"] = _range_to_range(df["stai_t"], 20.0, 80.0, 0.0, 21.0)
    mapped["depression"] = _range_to_range(df["cesd"], 0.0, 60.0, 0.0, 27.0)
    mapped["mental_health_history"] = pd.to_numeric(df["psyt"], errors="coerce")
    mapped["self_esteem"] = _range_to_range(df["health"], 1.0, 5.0, 0.0, 30.0)
    mapped["study_load"] = _range_to_range(df["stud_h"], 0.0, 70.0, 0.0, 5.0)
    mapped["academic_performance"] = _range_to_range(df["mbi_ea"], 10.0, 36.0, 0.0, 5.0)
    mapped["social_support"] = _binary_to_range(df["part"], 3.0)
    return ExternalDataset(
        key="medical_student_mental_health",
        display_name=EXTERNAL_DATASETS["medical_student_mental_health"].display_name,
        y=y,
        within_features=within,
        source_mapped_features=mapped,
        target_description="Proxy stress classes are tertiles of z(MBI emotional exhaustion)+z(MBI cynicism); MBI academic efficacy is not used in the proxy.",
        feature_description="Within-dataset features exclude MBI emotional exhaustion and cynicism used by the proxy target.",
    )


def _load_medical_student_mental_health_label_definition(raw_dir: str | Path, source_features: list[str]) -> ExternalDataset:
    path = Path(raw_dir) / "external" / "medical_student_mental_health" / "Data Carrard et al. 2022 MedTeach.csv"
    df = normalize_columns(pd.read_csv(path))
    stress_proxy = _z(df["mbi_ex"]) + _z(df["mbi_cy"])
    low_cut, high_cut = stress_proxy.quantile([1 / 3, 2 / 3]).to_list()
    y = pd.cut(stress_proxy, bins=[-np.inf, low_cut, high_cut, np.inf], labels=[0, 1, 2]).to_numpy(dtype=int)
    within = df.select_dtypes(include=[np.number]).drop(columns=["id"])
    mapped = _blank_source_frame(len(df), source_features)
    return ExternalDataset(
        key="medical_student_mental_health",
        display_name=EXTERNAL_DATASETS["medical_student_mental_health"].display_name,
        y=y,
        within_features=within.apply(pd.to_numeric, errors="coerce"),
        source_mapped_features=mapped,
        target_description="Label-definition protocol: proxy stress tertiles are predicted with the MBI emotional-exhaustion and cynicism components visible.",
        feature_description="Non-strict protocol for numeric reproducibility only; MBI components define the proxy target.",
    )


def _numeric_and_dummies(df: pd.DataFrame, exclude: list[str], categorical: list[str]) -> pd.DataFrame:
    exclude_set = set(exclude)
    numeric = df.drop(columns=[c for c in exclude if c in df.columns]).select_dtypes(include=[np.number]).copy()
    for col in categorical:
        if col in df.columns and col not in exclude_set:
            dummies = pd.get_dummies(df[col].astype(str).str.lower().str.strip(), prefix=col, dummy_na=True)
            numeric = pd.concat([numeric, dummies.astype(float)], axis=1)
    numeric = numeric.loc[:, ~numeric.columns.duplicated()].copy()
    return numeric.apply(pd.to_numeric, errors="coerce")


def _blank_source_frame(n_rows: int, source_features: list[str]) -> pd.DataFrame:
    return pd.DataFrame({name: np.full(n_rows, np.nan, dtype=float) for name in source_features})


def _range_to_range(values: pd.Series, in_min: float, in_max: float, out_min: float, out_max: float) -> pd.Series:
    values = pd.to_numeric(values, errors="coerce").clip(in_min, in_max)
    return out_min + ((values - in_min) / (in_max - in_min)) * (out_max - out_min)


def _binary_to_range(values: pd.Series, out_max: float) -> pd.Series:
    values = pd.to_numeric(values, errors="coerce").clip(0.0, 1.0)
    return values * out_max


def _dass_score(df: pd.DataFrame, items: list[int]) -> pd.Series:
    cols = [f"q{i}a" for i in items]
    responses = df[cols].apply(pd.to_numeric, errors="coerce")
    responses = responses.where(responses.ge(1) & responses.le(4))
    return responses.sub(1).sum(axis=1, min_count=len(cols))


def _z(values: pd.Series) -> pd.Series:
    values = pd.to_numeric(values, errors="coerce")
    return (values - values.mean()) / values.std(ddof=0)
