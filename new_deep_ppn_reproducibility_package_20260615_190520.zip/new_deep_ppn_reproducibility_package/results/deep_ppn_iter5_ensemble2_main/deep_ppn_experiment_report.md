# Deep PPN End-to-End Experiment Report

The model is named PPN in result tables and implemented as DeepPsychoPrototypicalNetwork: residual tabular encoder, learnable class prototypes, prototype-distance logits, and neural/prototype logit fusion.

## Best Configuration

```yaml
alpha: 0.02
batch_size: 64
beta: 0.08
class_balanced_loss: true
classifier_weight: 0.6
d_model: 128
deterministic_loader: true
distance_head_weight: 0.3
diversity_weight: 0.02
dropout: 0.12
encoder_variant: residual
ensemble_size: 2
epochs: 250
feature_gate_enabled: true
gradient_clip: 5.0
hidden_dim: 192
kmeans_init: true
label_smoothing: 0.05
learning_rate: 0.001
mlp_layers: 1
normalize_embeddings: false
num_prototypes: 9
optimizer: AdamW
patience: 35
pretrain_epochs: 20
proto_ce_weight: 0.1
prototype_temperature: 1.0
prototype_weight: 0.1
residual_blocks: 3
scheduler: cosine
separation_loss: margin
separation_margin: 0.5
weight_decay: 0.001

```

## Target Check

| main_macro_f1_target | main_accuracy_target | main_balanced_accuracy_target | external_label_definition_min_macro_f1 | main_macro_f1_reached | main_accuracy_reached | main_balanced_accuracy_reached | external_label_definition_reached |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0.9320 | 0.9290 | 0.9300 | 0.8700 | False | False | False | False |

## Main Dataset

| model | n_seeds | seed_list | accuracy_mean | accuracy_std | macro_precision_mean | macro_precision_std | macro_recall_mean | macro_recall_std | macro_f1_mean | macro_f1_std | balanced_accuracy_mean | balanced_accuracy_std | auc_ovr_mean | auc_ovr_std |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| PPN | 10.0000 | 2021,2022,2023,2024,2025,2026,2027,2028,2029,2030 | 0.9282 | 0.0083 | 0.9295 | 0.0090 | 0.9283 | 0.0083 | 0.9284 | 0.0085 | 0.9283 | 0.0083 | 0.9676 | 0.0101 |

## External Validation

External validation was not requested.

## Prototype Explanations

| prototype | assigned_class | nearest_neighbor_purity | top_contributing_features | profile_mean_top_features | evaluation_protocol | leakage_safe |
| --- | --- | --- | --- | --- | --- | --- |
| P1 | 0.0000 | 1.0000 | safety; teacher_student_relationship; basic_needs; sleep_quality; academic_performance | safety=+1.33; teacher_student_relationship=+1.25; basic_needs=+1.21; sleep_quality=+1.20; academic_performance=+1.20 | deep_ppn_test_nearest_neighbors | True |
| P2 | 0.0000 | 0.9800 | safety; sleep_quality; basic_needs; teacher_student_relationship; self_esteem | safety=+1.26; sleep_quality=+1.19; basic_needs=+1.09; teacher_student_relationship=+1.08; self_esteem=+1.07 | deep_ppn_test_nearest_neighbors | True |
| P3 | 0.0000 | 1.0000 | anxiety_level; safety; teacher_student_relationship; sleep_quality; basic_needs | anxiety_level=-1.29; safety=+1.24; teacher_student_relationship=+1.21; sleep_quality=+1.19; basic_needs=+1.17 | deep_ppn_test_nearest_neighbors | True |
| P4 | 1.0000 | 1.0000 | blood_pressure; social_support; breathing_problem; safety; self_esteem | blood_pressure=-1.44; social_support=+0.70; breathing_problem=+0.34; safety=-0.27; self_esteem=+0.24 | deep_ppn_test_nearest_neighbors | True |
| P5 | 1.0000 | 0.9800 | blood_pressure; social_support; safety; breathing_problem; peer_pressure | blood_pressure=-1.34; social_support=+0.60; safety=-0.32; breathing_problem=+0.26; peer_pressure=-0.21 | deep_ppn_test_nearest_neighbors | True |
| P6 | 1.0000 | 0.9800 | blood_pressure; social_support; safety; breathing_problem; sleep_quality | blood_pressure=-1.34; social_support=+0.56; safety=-0.35; breathing_problem=+0.29; sleep_quality=-0.24 | deep_ppn_test_nearest_neighbors | True |
| P7 | 2.0000 | 0.9800 | peer_pressure; future_career_concerns; bullying; self_esteem; extracurricular_activities | peer_pressure=+1.25; future_career_concerns=+1.25; bullying=+1.23; self_esteem=-1.21; extracurricular_activities=+1.17 | deep_ppn_test_nearest_neighbors | True |
| P8 | 2.0000 | 0.9800 | peer_pressure; bullying; future_career_concerns; extracurricular_activities; self_esteem | peer_pressure=+1.26; bullying=+1.23; future_career_concerns=+1.22; extracurricular_activities=+1.17; self_esteem=-1.13 | deep_ppn_test_nearest_neighbors | True |
| P9 | 2.0000 | 0.9600 | self_esteem; future_career_concerns; peer_pressure; extracurricular_activities; bullying | self_esteem=-1.29; future_career_concerns=+1.20; peer_pressure=+1.12; extracurricular_activities=+1.11; bullying=+1.08 | deep_ppn_test_nearest_neighbors | True |
| P10 | 0.0000 | 0.9200 | teacher_student_relationship; safety; basic_needs; sleep_quality; future_career_concerns | teacher_student_relationship=+1.15; safety=+1.14; basic_needs=+1.10; sleep_quality=+1.08; future_career_concerns=-1.08 | deep_ppn_test_nearest_neighbors | True |
| P11 | 0.0000 | 1.0000 | safety; teacher_student_relationship; basic_needs; academic_performance; sleep_quality | safety=+1.29; teacher_student_relationship=+1.29; basic_needs=+1.27; academic_performance=+1.19; sleep_quality=+1.14 | deep_ppn_test_nearest_neighbors | True |
| P12 | 0.0000 | 0.9200 | safety; basic_needs; teacher_student_relationship; future_career_concerns; sleep_quality | safety=+1.15; basic_needs=+1.10; teacher_student_relationship=+1.09; future_career_concerns=-1.08; sleep_quality=+1.03 | deep_ppn_test_nearest_neighbors | True |
| P13 | 1.0000 | 1.0000 | blood_pressure; social_support; breathing_problem; self_esteem; extracurricular_activities | blood_pressure=-1.44; social_support=+0.66; breathing_problem=+0.31; self_esteem=+0.29; extracurricular_activities=-0.28 | deep_ppn_test_nearest_neighbors | True |
| P14 | 1.0000 | 1.0000 | blood_pressure; social_support; self_esteem; breathing_problem; extracurricular_activities | blood_pressure=-1.44; social_support=+0.68; self_esteem=+0.33; breathing_problem=+0.28; extracurricular_activities=-0.28 | deep_ppn_test_nearest_neighbors | True |
| P15 | 1.0000 | 1.0000 | blood_pressure; social_support; breathing_problem; self_esteem; extracurricular_activities | blood_pressure=-1.44; social_support=+0.66; breathing_problem=+0.34; self_esteem=+0.29; extracurricular_activities=-0.28 | deep_ppn_test_nearest_neighbors | True |
| P16 | 2.0000 | 0.9800 | peer_pressure; future_career_concerns; extracurricular_activities; bullying; self_esteem | peer_pressure=+1.28; future_career_concerns=+1.24; extracurricular_activities=+1.23; bullying=+1.18; self_esteem=-1.17 | deep_ppn_test_nearest_neighbors | True |
| P17 | 2.0000 | 0.9800 | peer_pressure; future_career_concerns; bullying; self_esteem; extracurricular_activities | peer_pressure=+1.25; future_career_concerns=+1.24; bullying=+1.23; self_esteem=-1.21; extracurricular_activities=+1.17 | deep_ppn_test_nearest_neighbors | True |
| P18 | 2.0000 | 0.9600 | self_esteem; future_career_concerns; bullying; peer_pressure; extracurricular_activities | self_esteem=-1.23; future_career_concerns=+1.13; bullying=+1.09; peer_pressure=+1.07; extracurricular_activities=+1.06 | deep_ppn_test_nearest_neighbors | True |