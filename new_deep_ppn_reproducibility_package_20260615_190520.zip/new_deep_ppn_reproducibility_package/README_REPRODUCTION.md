# New Deep PPN Reproducibility Package

This package reproduces the redesigned end-to-end PPN model:

- `DeepPsychoPrototypicalNetwork`: feature gate + residual tabular encoder + learnable prototypes.
- Prototype-aware prediction: neural logits, class soft-min prototype logits, and learnable prototype-distance logits.
- `DeepPsychoPrototypicalEnsemble`: two PPN members with probability averaging for repeated-split stability.
- Prototype explanation outputs: nearest-neighbor purity, top contributing features, and standardized prototype profiles.

## Locked Results

Main Student Stress dataset, 10 repeated random splits:

- Accuracy: 0.9282 +/- 0.0083
- Macro-F1: 0.9284 +/- 0.0085
- Balanced Accuracy: 0.9283 +/- 0.0083
- AUC: 0.9676 +/- 0.0101

External label-definition within-dataset validation:

- Student Mental Health Dataset Macro-F1: 0.9644
- DASS-21 Response Dataset Macro-F1: 0.9369
- Medical Student Mental Health Dataset Macro-F1: 0.8911

## Reproduction Commands

Run the main 10-seed experiment:

```powershell
uv run python scripts/run_deep_ppn_experiments.py --config configs/v4.yaml --raw-dir data/raw --output-dir results/deep_ppn_iter5_ensemble2_main --main-split-seed 300 --deep-ppn-config results/deep_ppn_iter5_ensemble2_main/locked_deep_ppn_config.yaml --final-epochs 250 --seeds 2021 2022 2023 2024 2025 2026 2027 2028 2029 2030 --skip-external
```

Run the external label-definition validation using the locked model configuration:

```powershell
uv run python scripts/run_deep_ppn_experiments.py --config configs/v4.yaml --raw-dir data/raw --output-dir results/deep_ppn_iter5_ensemble2_external_label --deep-ppn-config results/deep_ppn_iter5_ensemble2_main/locked_deep_ppn_config.yaml --reuse-main-results results/deep_ppn_iter5_ensemble2_main --external-seeds 2021 2022 2023 2024 2025 --external-protocols label_definition --external-epochs 120 --external-pretrain-epochs 10 --external-patience 20 --external-batch-size 128
```

## Key Files

- `src/ppn/models/deep_ppn.py`: redesigned model and ensemble.
- `scripts/run_deep_ppn_experiments.py`: training, evaluation, external validation, and reporting.
- `results/deep_ppn_iter5_ensemble2_main/locked_deep_ppn_config.yaml`: locked final model config.
- `results/deep_ppn_iter5_ensemble2_main/deep_ppn_main_summary.csv`: main result summary.
- `results/deep_ppn_iter5_ensemble2_external_label/deep_ppn_external_summary.csv`: external result summary.
- `results/deep_ppn_iter5_ensemble2_main/deep_ppn_prototype_explanations.csv`: prototype explanations.

Note: label-definition external validation is not strict leakage-free transfer. It is included as a label-consistent external reproducibility protocol.
